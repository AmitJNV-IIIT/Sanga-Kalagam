package com.visanka.sangam;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

public class admin_class extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_page);


    }
}
