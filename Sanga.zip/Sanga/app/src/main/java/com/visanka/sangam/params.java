package com.visanka.sangam;

public class params {

    public static final String FILE_URL ="http://192.168.239.234/php/Register.php";
    public static final String MANAGER_URL ="http://192.168.239.234/php/manager.php";
    public static final String LOGIN_URL ="http://192.168.239.234/php/login.php";
    public static final String SUPERADMIN_URL ="http://192.168.239.234/php/superadmin.php";

    public static final String ADMIN_URL ="http://192.168.239.234/php/admin.php";

}
